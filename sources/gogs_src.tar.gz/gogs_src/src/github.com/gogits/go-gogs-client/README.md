Gogs API client in Go
=====================

This package is still in experiment, see [Wiki](https://github.com/gogits/go-gogs-client/wiki) for documentation.

## License

This project is under the MIT License. See the [LICENSE](https://github.com/gogits/gogs/blob/master/LICENSE) file for the full license text.