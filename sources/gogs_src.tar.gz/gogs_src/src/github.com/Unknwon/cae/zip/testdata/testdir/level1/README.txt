This small file is in ZIP64 format.
